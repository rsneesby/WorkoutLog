package com.example.ryan.workoutlog.Application.Domain.DomainInterfaces;

import com.example.ryan.workoutlog.Application.Domain.Exercise;

import java.util.Date;

public interface ResistanceExerciseInterface {


}
