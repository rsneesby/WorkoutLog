package com.example.ryan.workoutlog.Application.Domain.DomainInterfaces;

import java.util.Date;

public interface ExerciseInterface {

    public int getId();
    public String getExerciseName();
}
