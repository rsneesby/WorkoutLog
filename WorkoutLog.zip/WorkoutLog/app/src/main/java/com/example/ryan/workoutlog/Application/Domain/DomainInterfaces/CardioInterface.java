package com.example.ryan.workoutlog.Application.Domain.DomainInterfaces;

public interface CardioInterface {
}
