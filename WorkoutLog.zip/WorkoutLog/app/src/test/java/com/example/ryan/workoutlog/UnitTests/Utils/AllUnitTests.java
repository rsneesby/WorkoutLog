package com.example.ryan.workoutlog.UnitTests.Utils;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.example.ryan.workoutlog.UnitTests.*;

@RunWith(Suite.class)
@Suite.SuiteClasses({
    ExerciseLoggingLogicUnitTest.class
})
public class AllUnitTests {

}
